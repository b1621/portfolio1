const Sidebar = () => {
  const iconStyle = "w-9 h-9 bg-slate-100 rounded-full px-2 py-1";
  return (
    <div className=" w-32 border fixed h-full flex flex-col justify-end">
      <div className="border mb-10 ">
        <div className="border w-20 mx-auto space-y-3">
          <img
            className={iconStyle}
            src="/pageicons/briefing_1705213.png"
            alt=""
          />
          <img className={iconStyle} src="/pageicons/contact-mail.png" alt="" />
          <img className={iconStyle} src="/pageicons/contact.png" alt="" />
          <img className={iconStyle} src="/pageicons/user.png" alt="" />
        </div>
      </div>
    </div>
  );
};

export default Sidebar;
